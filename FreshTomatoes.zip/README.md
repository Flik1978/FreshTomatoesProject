# Fresh Tomatoes
These files will create a new local webpage, fresh_tomatoes.html in the same folder as the other files and then open up the HTML file in your default browser.  The page will show six movie box art photos with the movie title below them, which will show a preview clip in it's own window when clicked.  You can close the pop-up window in order to view another movie clip.  

## What you will need
Before you are able to run the following files, you will need to install the Python 2.7 interpreter or a text editor such as, Atom, Sublime or Notepad ++.

## Installation
You will need to download the files either individually or in the FreshTomatoes zip file.  Please make sure that all the files are in the same folder in order for the entertainment_center.py file to function properly.  You will then open either Python 2.7 IDLE or a text editor to run the entertainment_center.py file, which will create a the fresh_tomatoes.html file and then open it in your default browser.      

## Possible issues
Although, the videos have been tested in the latest versions of Chrome, Internet explorer and Firefox; you may run into one of the following issues:
* **Issue:** _This video contains content from...  It is restricted from playback on certain sites or applications.  
Watch on YouTube._  
**Resolution:** Click on the Watch on YouTube link provided.  

* **Issue:** _This video is not available in your country.  
Sorry about that._  
**Resolution:** None at this time
